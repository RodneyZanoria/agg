# Direction 3: Command Presence
**Score: 42/50**

## Design Thesis
A cinematic dark-premium site that establishes Anne's authority before the first scroll — using quantified proof as visual architecture and conversion language tuned precisely to event planners who manage world-class speakers. Competitors feel cheap by comparison.

## Typography Pairings
| Role | Font | Weight | Size |
|---|---|---|---|
| Display / H1 | Syne | 800 | clamp(3rem, 7vw, 6.5rem) |
| H2–H3 | Syne | 700 | clamp(1.8rem, 4vw, 3rem) |
| Body | Outfit | 300/400 | 1rem (16px) |
| Labels / Caps | Outfit | 600 | 0.7rem, letter-spacing: 0.16em |
| Stats display | Syne | 800 | clamp(4rem, 9vw, 8rem) |

Scale ratio: 1.333 (perfect fourth)

## Color Tokens
```css
--base: #0F0F0F           /* near black — 60% */
--surface: #1A1A1A        /* dark surface */
--surface-mid: #252525    /* card/section backgrounds */
--cream: #F2EAD9          /* warm cream — primary text */
--cream-muted: #9A9080    /* muted text */
--amber: #E09A2B          /* amber gold accent — 10% */
--amber-light: #EDB14E    /* amber hover */
--white: #FFFFFF
```

## Homepage Section Structure
1. **Nav** — Dark, minimal. Logo white + nav cream. Amber "Check Availability" CTA. Solid dark background.
2. **Hero** — Full-bleed dark. Anne's portrait left (80% height), massive bold stats right. Syne 800 making text a visual element.
3. **Client Logos** — Dark surface band. Logos in cream/50% opacity. One standout quote.
4. **Speaking Topics** — Dark surface cards. Amber numbering. Hover reveals amber border.
5. **Stats Feature** — Near-black section: 3 huge Syne 800 numbers with cream labels. Cinematic.
6. **Testimonials** — Two-column. Dark surface cards. Amber quotation mark.
7. **Authority Block** — Fullwidth dark, cream type. Photo right, content left.
8. **Books** — Dark surface section. Dramatic shadow on book covers.
9. **Final CTA** — Amber background. Dark text. Maximum contrast and urgency.

## Mobile Behaviors
- Navigation: dark hamburger overlay from right side
- Hero: portrait fills full width, stats beneath in a dark grid
- Stats numbers maintain dominance at clamp sizes
- Topic cards: full-width with amber left border on mobile
- Sticky mobile CTA: amber pill fixed bottom
- Padding: generous (clamp(3rem, 6vw, 5rem) per section)

## WordPress Mapping Notes
- Block theme: Generate Press Pro or Kadence with FSE
- Set `color.background` in theme.json to `#0F0F0F`
- Body color in theme.json to `#F2EAD9`
- Syne → Google Fonts (self-host 700+800 weights only)
- Outfit → Google Fonts (300+400 weights only)
- Admin Bar: Will need CSS override for contrast
- Dark section patterns: Use Cover Block with dark overlay for any section needing a photo bg
- Stats section: Static HTML pattern with real numbers — no plugin needed
- Book cover shadows: Custom CSS added to Core/Image block for the dramatic shadow effect
- Amber CTA button: Register as a custom button style variation in theme.json
