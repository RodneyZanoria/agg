# Direction 2: Clear Signal
**Score: 44/50 — Highest Ranked**

## Design Thesis
An evidence-first editorial site where proof is a design element, not an afterthought — logos, stats, and a testimonial are unavoidable before the first scroll — converting event planners through ruthless clarity of offer and elimination of every non-essential element.

## Typography Pairings
| Role | Font | Weight | Size |
|---|---|---|---|
| Display / H1 | Fraunces (variable) | 600 | clamp(3.5rem, 7vw, 7rem) |
| H2–H3 | Fraunces | 400 | clamp(2rem, 4vw, 3.5rem) |
| Body | Satoshi / Outfit fallback | 400 | 1.0625rem (17px) |
| Labels / Caps | Satoshi | 600 | 0.75rem, letter-spacing: 0.14em |
| Pull quotes | Fraunces italic | 300 | clamp(1.5rem, 3vw, 2.5rem) |

Scale ratio: 1.414 (augmented fourth — gives headlines maximum dominance)

## Color Tokens
```css
--base: #FFFFFF            /* pure white — 60% */
--surface: #F7F5F1         /* warm off-white — 30% */
--forest: #0D2B1D          /* deep forest green — structural */
--forest-mid: #1A4030      /* mid-forest for hover states */
--gold: #B89A4E            /* champagne gold — 10% accent */
--gold-light: #C9AE68      /* gold hover */
--text: #0A0A08            /* near black */
--text-muted: #4A4A46      /* muted body text */
```

## Homepage Section Structure
1. **Sticky Nav** — Minimal: logo + sparse links + "Check Availability" in forest green
2. **Proof Ribbon** — Thin strip: logo bar + one standout stat. Sticky at top, below nav. Transitions on scroll.
3. **Hero** — Full-width editorial layout: massive Fraunces headline (left 60%), Anne's photo (right 40%, cropped editorial). Off-white bg.
4. **Impact Stats** — 3 large statistics on forest green background, white type — design-forward proof
5. **Speaking Topics** — White bg, 3 stacked editorial cards with clear topic → outcome structure
6. **Testimonial Feature** — Forest green band, gold pull quote, source attribution
7. **Authority / About** — Split layout: content left, photo right. Evidence-dense.
8. **Books** — Off-white bg, horizontal book display with editorial caption structure
9. **Final CTA** — Full-width forest green, white headline, friction-reducing copy

## Mobile Behaviors
- Proof ribbon collapses to scrolling ticker on mobile
- Hero: stacks vertically, photo becomes 100vw bleed image above the fold text
- Stats: vertical stack of 3 on mobile (full width each)
- Topic cards: full-width on mobile, accordion behavior optional
- Sticky bottom CTA button on mobile
- Navigation: hamburger, overlay slides from right
- Font sizes: fluid via clamp() — no abrupt jumps

## WordPress Mapping Notes
- Block theme: Kadence or GeneratePress Pro with FSE
- Colors → theme.json `settings.color.palette` with exact hex values above
- Fraunces → Google Fonts, self-hosted via `@font-face` post-install
- Satoshi → Fontshare.com, self-hosted (free for commercial use)
- Proof ribbon: Synced Pattern — reused on all key landing pages
- Stats section: Static HTML Pattern (numbers are real, no counter plugin needed)
- Topic cards: Custom post type "Speaking Topics" → query block with editorial card template
- Hero layout: Cover Block (for photo bg option) or Columns Block (for side-by-side)
- FSE Header template: Navigation block + custom "Check Availability" button variant
- Testimonial feature: Synced pattern `agp/testimonial-forest`
