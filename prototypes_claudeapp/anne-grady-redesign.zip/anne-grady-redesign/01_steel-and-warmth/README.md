# Direction 1: Steel & Warmth
**Score: 43/50**

## Design Thesis
A warm-authoritative site that makes resilience feel both achievable and urgent, by pairing editorial precision with human warmth — eliminating the cluttered proof-dumping that makes competitors feel generic.

## Typography Pairings
| Role | Font | Weight | Size |
|---|---|---|---|
| Display / H1 | DM Serif Display | 400 | clamp(3rem, 6vw, 5.5rem) |
| H2–H3 | DM Serif Display | 400 | clamp(1.8rem, 3.5vw, 2.8rem) |
| Body | Outfit | 300/400 | 1.0625rem (17px) |
| Labels / Caps | Outfit | 600 | 0.75rem, letter-spacing: 0.12em |

Scale ratio: 1.333 (perfect fourth)

## Color Tokens
```css
--base: #FAF8F5       /* warm white — 60% */
--surface: #EDE8E0    /* warm cream — 30% */
--navy: #1A2B3C       /* deep navy — structural */
--terracotta: #C45C2E /* accent — 10% */
--text: #1C1C1A       /* near black */
--text-muted: #5C5A57 /* muted text */
```

## Homepage Section Structure
1. **Sticky Nav** — Logo left, nav center, "Check Availability" right (sticky on scroll, transparent at top)
2. **Hero** — Two-column: headline + CTA left, Anne's portrait right. Warm white bg. Subtle fade-up animation.
3. **Social Proof Bar** — Full-width navy band: 5–6 client logos + 1 stat ("500+ keynotes delivered")
4. **Speaking Topics** — 3-column card grid on cream bg: Topic name, target audience, key outcome, "Learn More" link
5. **Outcomes Block** — Alternating text+image layout: what event planners get (outcomes-first language)
6. **Testimonials** — 2 cards on white: quote, name, title, company logo
7. **Authority Block** — Anne bio with photo, 3 credibility stats, press logo strip
8. **Book Covers** — Cream bg, 2–3 books displayed with title + CTA
9. **Final CTA** — Navy background: friction-reduced inquiry CTA

## Mobile Behaviors
- Single column layout below 768px
- Hero: portrait moves below headline on mobile (aspect-ratio crop)
- Logo bar: 3-column grid, scrolls horizontally on very small screens
- Navigation: hamburger menu, slide-in overlay
- Sticky CTA: "Check Availability" button fixed at bottom on mobile
- Section padding: 4rem mobile, 8rem desktop
- Font sizes: fluid scaling via clamp() — no hard mobile breakpoint jumps

## WordPress Mapping Notes
- Block theme: Kadence or GeneratePress Pro with FSE enabled
- Hero pattern: `agp/hero-steel` — 2-col group block with cover block right
- Proof bar: Synced pattern (`agp/proof-bar`) — used on Home and About
- Topic cards: Custom post type "Speaking Topics" → loop block with card template
- Testimonials: Custom post type "Testimonials" → query loop with card pattern
- Color tokens → theme.json `settings.color.palette`
- Typography → theme.json `settings.typography.fontFamilies`
- Sticky nav CTA: Added via Navigation block + custom button variant style
