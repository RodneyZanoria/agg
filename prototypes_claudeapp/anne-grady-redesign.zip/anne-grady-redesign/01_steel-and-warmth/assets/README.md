# Assets — Required Files

## Portrait Photos
- `anne-grady-portrait-hero.webp` — Hero portrait, 1200×1500px WebP (object-fit: cover)
- `anne-grady-headshot-authority.webp` — Authority section headshot, 600×750px WebP
- `anne-grady-on-stage.webp` — Outcomes section, Anne on stage/with audience, 800×1000px WebP

## Client Logos (logos/)
Place in this folder with consistent naming:
- `walgreens-white.svg` — White/light variant for dark backgrounds
- `ibm-white.svg`
- `microsoft-white.svg`
- `google-white.svg`
- `johnson-johnson-white.svg`
- `bridgestone-white.svg`
- `general-mills-white.svg`
Also provide dark variants (e.g. `walgreens-dark.svg`) for light backgrounds.

## Book Covers (books/)
- `flexability-cover.webp` — 400×600px WebP
- `mind-over-moment-cover.webp` — 400×600px WebP
- `strong-enough-cover.webp` — 400×600px WebP

## Press Logos (press/)
- `nbc-dark.svg` / `nbc-white.svg`
- `cbs-dark.svg` / `cbs-white.svg`
- `forbes-dark.svg` / `forbes-white.svg`
- `inc-dark.svg` / `inc-white.svg`
- `fast-company-dark.svg` / `fast-company-white.svg`

## Optimization Notes
- All photos: export as WebP, optimize with Squoosh before upload
- Logos: SVG preferred; PNG fallback at 2x resolution
- Alt text template: "Anne Grady [description] — resilience keynote speaker"
