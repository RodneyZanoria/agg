# Competitor Benchmark: Anne Grady Group Redesign
*Skill: design-systems-wordpress | Role: UI/UX Lead + SEO Specialist*

---

## Site 1: Anne Grady Group (Existing) — annegradygroup.com

### Hero Pattern
- Full-bleed photo of Anne with purple dress, text overlaid
- Headline: "Adapt. Lead. Grow Forward" — reasonable clarity, but weak benefit specificity
- Sub: "Help teams adapt faster, recover stronger, and grow through change" — functional but generic
- Primary CTA: "BOOK NOW" — high friction label (implies commitment vs. inquiry)
- No secondary CTA visible

### Visual System
- Typography: Mix of serif and sans, inconsistent weight hierarchy
- Palette: Purple (#6B21A8 range), orange accents, green accents — three accent colors competing
- Spacing: Tight, dense — little breathing room between sections
- Imagery: Good quality headshot but hero crop is not optimized for authority

### Conversion Mechanics
- CTA label "Book Now" creates friction for event planners exploring options
- No sticky navigation CTA on scroll
- Inquiry path buried — unclear where to start the booking conversation
- No visible availability or topic inquiry form near top

### Section Order
Hero → Book promo section → Video section → Course promo → Programs grid → Logo bar → Testimonial → Press/Media grid → Newsletter → Amazon book links → Footer

### Mobile Behavior
- Navigation collapses to hamburger
- Hero headline readable but photo composition breaks on mobile
- Dense logo grid and media grid compress poorly
- No sticky CTA on mobile

### Perceived Credibility
- Logo bar present but positioned mid-page (Walgreens, IBM, Google, Microsoft, etc. — strong)
- Testimonial present but only one near bottom
- Press/media section strong but too far down
- Book covers present but not featured prominently

### Strengths Worth Noting
- Strong brand asset: Anne's headshot / presence is compelling
- Corporate client logos are A-tier (Fortune 500)
- Real press coverage (TV appearances, media)
- Book assets are credibility multipliers

### Weaknesses to Fix
- Purple/orange/green tri-color system feels 2014
- Too many competing sections — no singular narrative
- "Book Now" CTA creates commitment fear vs. "Check Availability" softness
- Logo bar positioned too low
- No outcomes-first language for event planners
- Typography lacks premium hierarchy
- No sticky conversion mechanism on scroll

---

## Site 2: Simon T. Bailey — simontbailey.com (Competitor Reference)

### Hero Pattern
- Dark background, large editorial portrait
- Name displayed as display type — identity-first positioning
- Tagline: "Executive Advisor, Researcher, and Speaker" — credential-first
- CTAs present but could be stronger

### Visual System
- Typography: Bold display sans for name, medium weight for body — strong hierarchy
- Palette: Navy (#1A2040), Gold/Yellow (#F5C518), White — clean three-color system
- Spacing: More generous than AGG — feels premium
- Grid-breaking elements: Photo overlaps sections creating depth

### Conversion Mechanics
- Better CTA hierarchy than AGG
- Social proof positioned early (stats: 81%, 55%, 82% leadership statistics)
- Multiple topic pathways visible

### Mobile Behavior
- Navigation cleaner
- Better text sizing
- More consistent spacing rhythm

### Perceived Credibility
- Statistics-driven proof section is strong
- Quote callouts distributed through page
- Better visual rhythm of proof → offer → proof

### Strengths Worth Matching
- Dark/light section alternation creates premium reading rhythm
- Statistics as proof (quantified outcomes) — compelling for event planners
- Strong name/identity branding above the fold
- Clean three-color system

### Weaknesses to Out-Execute
- Hero is identity-first, not outcome-first for the buyer (event planner)
- Topic architecture is vague — "speaking" not broken into clear topics
- No sticky conversion path
- Typography while bolder still feels template-adjacent
- CTA language could be more friction-reducing

---

## Benchmark Summary Table

| Dimension | Anne Grady Group (Current) | Simon T. Bailey | Target Benchmark |
|---|---|---|---|
| Hero clarity (10 sec offer) | 6/10 — generic resilience framing | 6/10 — identity-first, not buyer-first | 9/10 — outcome + buyer + proof |
| Proof above fold | 4/10 — logos buried mid-page | 7/10 — stats visible | 9/10 — logos + stats + quote visible |
| Event planner conversion path | 5/10 — "Book Now" high friction | 6/10 — reasonable but unclear | 9/10 — "Check Availability" + topic inquiry |
| Mobile polish | 5/10 — dense, no sticky CTA | 7/10 — cleaner spacing | 9/10 — sticky CTA, clean rhythm |
| Visual premium feel | 5/10 — dated palette | 7/10 — cleaner but template-adjacent | 9/10 — distinctive, spacious, editorial |
| Typography system | 4/10 — inconsistent hierarchy | 7/10 — clear weight hierarchy | 9/10 — distinctive display + refined body |
| Topic architecture | 6/10 — listed but not outcomes-first | 5/10 — vague | 9/10 — topic → outcome → audience |
| Speed discipline | 6/10 — heavy section stack | 6/10 — moderate | 9/10 — lightweight, no layout shift |

---

## Patterns Worth Matching (from both sites)
1. Fortune 500 client logos displayed prominently (AGG owns this — surface it earlier)
2. Quantified outcomes / statistics as social proof (Bailey does this well)
3. Strong speaker portrait as hero anchor
4. Dark/light section rhythm for reading engagement (Bailey)
5. Book covers as authority multipliers (AGG — feature more prominently)

## Patterns to Avoid
1. Three competing accent colors (AGG)
2. "Book Now" as primary CTA — too high commitment
3. Logo bar buried past fold 3
4. Dense media grid without hierarchy
5. Biography-first about section (event planners buy outcomes, not bios)
6. Heavy plugin assumptions / layout shift
7. Newsletter popup-style email capture above conversion CTAs
