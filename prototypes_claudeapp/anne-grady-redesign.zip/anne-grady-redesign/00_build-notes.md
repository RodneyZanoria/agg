# WordPress Build Notes — Anne Grady Group Redesign
*Implementation checklist for all 3 selected directions*

---

## Universal Foundation (All Three Directions)

### Theme Approach
- **Recommended:** Block theme with Full Site Editing (FSE) — GeneratePress or Kadence as the base block theme, customized via theme.json
- **Alternative:** Blocksy or Neve if FSE workflow is unfamiliar
- **Avoid:** Divi, Elementor, WPBakery — add unnecessary JS/CSS weight and lock content into proprietary formats

### theme.json Global Styles (Required for All Directions)
Each direction has its own token set. Map color tokens, typography, and spacing into theme.json:
```json
{
  "settings": {
    "color": {
      "palette": [{ "name": "Primary", "slug": "primary", "color": "#..." }]
    },
    "typography": {
      "fontFamilies": [{ "name": "Display", "slug": "display", "fontFamily": "..." }]
    },
    "spacing": {
      "units": ["px", "rem", "%", "vw"]
    }
  }
}
```

### Font Loading Strategy
- Self-host Google Fonts using `@font-face` or the Google Fonts Helper tool
- Add `font-display: swap` to all custom font declarations
- Limit to 2 font families max per direction
- Preload the display font file in `<head>`

### Performance Baseline
- Install WP Rocket or LiteSpeed Cache (match to host)
- Use Cloudflare or BunnyCDN for asset delivery
- Install EWWW Image Optimizer for automatic WebP conversion
- Target: LCP < 2.5s, CLS < 0.1, FID < 100ms

### Plugin Budget (Keep Minimal)
| Function | Recommended Plugin |
|---|---|
| SEO | Rank Math (free tier sufficient) |
| Forms | Gravity Forms or WPForms (for speaker inquiry) |
| Caching | WP Rocket or LiteSpeed Cache |
| Image optimization | EWWW or Imagify |
| Security | Wordfence (free) or Solid Security |
| Schema | Rank Math handles Person + Organization schema |

### Media and Asset Workflow
1. Export all photos to WebP before uploading (use Squoosh or equivalent)
2. Hero photo: 2400px wide max, WebP, optimized for above-fold LCP
3. Logo bar: Use SVG files where possible, PNG with white/dark variants
4. Book covers: High-res PNG, ensure transparent background variant available
5. Set alt text template: "Anne Grady [context description] — resilience keynote speaker"

---

## Direction 1: Steel & Warmth — WordPress Specifics

### Color Token Map (theme.json)
```
--color-base: #FAF8F5
--color-surface: #EDE8E0
--color-navy: #1A2B3C
--color-terracotta: #C45C2E
--color-text: #1C1C1A
--color-text-muted: #5C5A57
```

### Typography Map (theme.json)
- Display: DM Serif Display, 400 weight — load via Google Fonts
- Body: Outfit, 300/400/600 weights — load via Google Fonts
- H1: clamp(2.8rem, 6vw, 5.5rem), DM Serif Display
- H2: clamp(1.8rem, 3.5vw, 2.8rem), DM Serif Display
- Body: 1.125rem (18px), Outfit 400, line-height 1.65

### Block Patterns to Create
1. `agp/hero-steel` — full-width hero with portrait right, headline left, dual CTAs
2. `agp/proof-bar` — logo strip + one stat + one quote excerpt
3. `agp/topic-card` — topic name + audience + outcome + CTA link
4. `agp/testimonial-warm` — quote + name + company + headshot
5. `agp/book-shelf` — 2–3 book covers with title and CTA
6. `agp/authority-block` — Anne bio with photo, stats, press logos
7. `agp/cta-final` — warm inquiry CTA with friction-reducing copy

### Page Templates Required
- Home (custom template)
- Speaking Topics (archive + individual topic pages)
- Programs / Services
- About
- Blog (standard post template)
- Contact / Speaker Inquiry (form-centered)
- Press / Media Kit

---

## Direction 2: Clear Signal — WordPress Specifics

### Color Token Map (theme.json)
```
--color-base: #FFFFFF
--color-surface: #F7F5F1
--color-forest: #0D2B1D
--color-gold: #B89A4E
--color-text: #0A0A08
--color-text-muted: #4A4A46
```

### Typography Map (theme.json)
- Display: Fraunces (variable), weight 300–700 — load via Google Fonts
- Body: Satoshi (or Outfit as fallback) — self-host Satoshi from fontshare.com
- H1: clamp(3.5rem, 7vw, 7rem), Fraunces 600, tight letter-spacing
- H2: clamp(2rem, 4vw, 3.5rem), Fraunces 400
- Body: 1.0625rem (17px), Satoshi 400, line-height 1.7

### Key Design Implementation Notes
- Proof bar is a full-width band using `--color-forest` background — sticky until hero exits viewport
- Hero headline uses CSS `font-size: clamp()` for fluid scaling — no JS needed
- Logo grid: 6-column on desktop, 3-column on mobile, SVG assets
- Stats counters: CSS counter-animation with `@keyframes` — no JS number-counting plugins

---

## Direction 3: Command Presence — WordPress Specifics

### Color Token Map (theme.json)
```
--color-base: #0F0F0F
--color-surface: #1A1A1A
--color-cream: #F2EAD9
--color-amber: #E09A2B
--color-text: #F2EAD9
--color-text-muted: #9A9080
```

### Typography Map (theme.json)
- Display: Syne, 700/800 weights — load via Google Fonts
- Body: Outfit, 300/400 weights
- H1: clamp(3rem, 7vw, 6.5rem), Syne 800, all-caps letter-spacing: 0.02em
- H2: clamp(1.8rem, 4vw, 3rem), Syne 700
- Body: 1rem (16px), Outfit 300, line-height 1.75, color: --color-cream

### Dark Theme WordPress Notes
- Set `color.background` in theme.json to `#0F0F0F`
- Admin bar contrast: ensure wp-admin-bar background is handled
- Image treatment: recommend dark-overlay on hero photo via CSS `mix-blend-mode: multiply` on overlay layer
- Statistics section: use CSS `counter()` or minimal vanilla JS for number animation — no plugin needed

---

## SEO Implementation Checklist (All Directions)

### Rank Math / On-Page SEO
- [ ] Set H1 to: "Resilience Keynote Speaker | Anne Grady" (homepage)
- [ ] Meta description: "Anne Grady Group — keynote speaker, author, and resilience expert. Book Anne for your next conference, leadership summit, or corporate event."
- [ ] Set canonical URL
- [ ] Enable breadcrumbs for interior pages

### Schema Markup (Rank Math handles via UI)
- Person schema: Anne Grady — speaker, author, organizational role
- Organization schema: Anne Grady Group — type: ProfessionalService
- Event schema: Can be added per event/speaking page
- Book schema: For each published book

### Core Web Vitals Targets
- LCP: Preload hero image, self-host fonts, use WebP
- CLS: Set explicit width/height on all images and logo assets
- FID/INP: Minimize JS, no heavy UI frameworks

### Internal Linking Strategy
- Homepage → Speaking Topics (individual topic pages)
- Homepage → About (credibility expansion)
- Homepage → Contact/Inquiry (conversion)
- Blog posts → relevant speaking topic pages
- Press/media → About page

---

## Launch Checklist

- [ ] All logo SVGs uploaded with dark and light variants
- [ ] Hero photo exported at 2400px WebP, alt text set
- [ ] Book cover images with transparent background variant
- [ ] All font files self-hosted with font-display: swap
- [ ] Speaker inquiry form tested end-to-end
- [ ] Email notification routing confirmed
- [ ] Google Analytics 4 + Search Console connected via Rank Math
- [ ] Core Web Vitals baseline measurement taken pre-launch
- [ ] Mobile sticky CTA behavior verified on real device
- [ ] Accessibility audit: heading hierarchy, contrast ratios, keyboard nav, focus states
