# Design Direction Scoring — Anne Grady Group Redesign
*5 Candidate Directions → Top 3 Selected*

---

## Scoring Rubric (each criterion 1–10)
1. **Offer Clarity** — Is the value proposition clear to an event planner within 10 seconds?
2. **Credibility Density** — Is proof (logos, stats, quotes, press) visible above fold and distributed well?
3. **Conversion Path** — Is the event planner's inquiry journey frictionless and obvious?
4. **Mobile Polish** — Is spacing, type scale, and sticky CTA behavior strong on mobile?
5. **Speed Discipline** — Is the layout lightweight, minimal JS dependency, no layout shift?

---

## Direction 1: "Steel & Warmth"

**Concept:** Warm white dominant (#FAF8F5), deep navy structural color (#1A2B3C), single terracotta accent (#C45C2E). DM Serif Display headlines + Outfit body. Asymmetric hero with Anne's portrait right-anchored, headline left. Trust bar immediately below hero with logos + one stat. Alternating cream/white section rhythm.

**Design Thesis:** "A warm-authoritative site that makes resilience feel both achievable and urgent, by pairing editorial precision with human warmth — eliminating the cluttered proof-dumping that makes competitors feel generic."

| Criterion | Score | Justification |
|---|---|---|
| Offer Clarity | 9 | Hero positions "resilience that works in the room" with clear outcome subhead |
| Credibility Density | 8 | Logo bar + one stat + testimonial snippet at fold 2 |
| Conversion Path | 9 | "Check Availability" CTA + sticky nav button on scroll |
| Mobile Polish | 8 | Mobile-first grid, sticky header CTA, generous spacing |
| Speed Discipline | 9 | Minimal JS, CSS-only animations, no heavy background assets |
| **TOTAL** | **43/50** | |

---

## Direction 2: "Clear Signal"

**Concept:** Pure white + deep forest green (#0D2B1D) + champagne gold (#B89A4E) + warm off-white (#F7F5F1). Fraunces serif display + Satoshi sans body. Full-bleed minimal hero — massive headline text as the visual anchor, photo inset in editorial float. Maximum whitespace. Evidence stacks early and deliberately.

**Design Thesis:** "An evidence-first editorial site where proof is the visual system — logos, stats, and a testimonial are unavoidable before the scroll — converting event planners through ruthless clarity of offer and elimination of every non-essential element."

| Criterion | Score | Justification |
|---|---|---|
| Offer Clarity | 9 | Headline size forces reading — single declarative benefit |
| Credibility Density | 9 | Proof bar is a design element at the top, not an afterthought |
| Conversion Path | 8 | Clear CTA hierarchy, clean path, but slightly less warm friction-reduction |
| Mobile Polish | 9 | Whitespace-led mobile scales beautifully, sticky header clean |
| Speed Discipline | 9 | Ultra-lightweight layout, minimal background rendering cost |
| **TOTAL** | **44/50** | |

---

## Direction 3: "Cascade Architecture"

**Concept:** Cool slate gray (#2D3748) dominant with lavender accent (#8B7CF6) and warm cream text. Syne + Inter pairing. Diagonal geometric background shapes. Strong section dividers using diagonal clips.

**Design Thesis:** "A structured corporate-speaker site using geometric precision to signal premium reliability, with diagonal layout breaks conveying forward momentum."

| Criterion | Score | Justification |
|---|---|---|
| Offer Clarity | 7 | Geometric elements compete with the message |
| Credibility Density | 7 | Proof present but geometric structure distracts |
| Conversion Path | 7 | Good CTA placement, but diagonal layouts create cognitive friction |
| Mobile Polish | 7 | Diagonal clips create mobile rendering complications |
| Speed Discipline | 7 | Clip-path on sections adds render cost |
| **TOTAL** | **35/50** | |

---

## Direction 4: "Command Presence"

**Concept:** Near-black (#0F0F0F) dominant, warm cream (#F2EAD9) text, amber gold (#E09A2B) accent. Syne display + Outfit body. Cinematic full-bleed dark hero with Anne's portrait as the visual anchor — backlighting or silhouette treatment. Statistics as design elements. Event planner language throughout.

**Design Thesis:** "A cinematic dark-premium site that establishes Anne's authority before the first scroll, using quantified proof as visual architecture and conversion language tuned precisely to event planners who manage world-class speakers."

| Criterion | Score | Justification |
|---|---|---|
| Offer Clarity | 8 | Dark treatment reinforces authority but slightly reduces scan-speed |
| Credibility Density | 9 | Statistics as graphic design is distinctive and compelling |
| Conversion Path | 9 | Event planner language is explicit and strong |
| Mobile Polish | 8 | Dark-mode mobile is excellent, sticky CTA works well |
| Speed Discipline | 8 | Background treatment costs some rendering vs. pure white |
| **TOTAL** | **42/50** | |

---

## Direction 5: "Quiet Resilience"

**Concept:** Taupe/sand dominant (#E8DDD0), warm gray secondary (#8C8078), black text, no accent color — restraint as the design system. Cormorant Garamond large + Cabinet Grotesk body. Photography carries all emotional weight. Almost fashion-editorial in restraint.

**Design Thesis:** "A fashion-editorial restraint site where Anne's photography is the entire visual system — typography is servant to imagery, making competitors feel loud and cheap by contrast."

| Criterion | Score | Justification |
|---|---|---|
| Offer Clarity | 6 | Restraint risks under-communicating the offer |
| Credibility Density | 6 | Too restrained — logos and stats feel at odds with the aesthetic |
| Conversion Path | 7 | Clean but conversion elements lack urgency |
| Mobile Polish | 8 | Beautiful on mobile but low conversion energy |
| Speed Discipline | 9 | Minimal everything |
| **TOTAL** | **36/50** | |

---

## Final Rankings

| Rank | Direction | Score | Selected |
|---|---|---|---|
| 1 | Clear Signal | 44/50 | YES |
| 2 | Steel & Warmth | 43/50 | YES |
| 3 | Command Presence | 42/50 | YES |
| 4 | Quiet Resilience | 36/50 | No |
| 5 | Cascade Architecture | 35/50 | No |

## Top 3 Selection Rationale

**Clear Signal (Direction 2)** scores highest because its commitment to evidence-as-design-system directly addresses the biggest weakness of both the current site and the competitor: proof is buried. The forest green + champagne gold system is distinctive and ownable. Fraunces is editorial and warm without being feminine-cliché.

**Steel & Warmth (Direction 1)** wins the emotional brief — "less is more" + "impactful" + "modern spacious." The terracotta accent creates warmth that differentiates from the cold-premium speaker market. DM Serif Display is authoritative without feeling corporate-stiff.

**Command Presence (Direction 4)** captures the premium dark-speaker aesthetic that event planners associate with world-class keynotes. It deliberately targets the buyer mindset: event planners see a premium experience, not just a speaker website. The statistics-as-design-elements approach is the most distinctive element in the set.
